/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'sq', {
	label: 'Stil',
	panelTitle: 'Stilet e Formatimit',
	panelTitle1: 'Stilet e Bllokut',
	panelTitle2: 'Stili i Brendshëm',
	panelTitle3: 'Stilet e Objektit'
} );
