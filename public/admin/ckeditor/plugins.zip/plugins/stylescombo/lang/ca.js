/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ca', {
	label: 'Estil',
	panelTitle: 'Estils de format',
	panelTitle1: 'Estils de bloc',
	panelTitle2: 'Estils incrustats',
	panelTitle3: 'Estils d\'objecte'
} );
