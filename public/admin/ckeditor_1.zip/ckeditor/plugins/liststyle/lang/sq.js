/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'liststyle', 'sq', {
	armenian: 'Numërim armenian',
	bulletedTitle: 'Karakteristikat e Listës me Pulla',
	circle: 'Rreth',
	decimal: 'Decimal (1, 2, 3, etj.)',
	decimalLeadingZero: 'Decimal me zerro udhëheqëse (01, 02, 03, etj.)',
	disc: 'Disk',
	georgian: 'Numërim gjeorgjian (an, ban, gan, etj.)',
	lowerAlpha: 'Të vogla alfa (a, b, c, d, e, etj.)',
	lowerGreek: 'Të vogla greke (alpha, beta, gamma, etj.)',
	lowerRoman: 'Të vogla romake (i, ii, iii, iv, v, etj.)',
	none: 'Asnjë',
	notset: '<e pazgjedhur>',
	numberedTitle: 'Karakteristikat e Listës me Numra',
	square: 'Katror',
	start: 'Fillimi',
	type: 'LLoji',
	upperAlpha: 'Të mëdha alfa (A, B, C, D, E, etj.)',
	upperRoman: 'Të mëdha romake (I, II, III, IV, V, etj.)',
	validateStartNumber: 'Numri i fillimit të listës duhet të është numër i plotë.'
} );
