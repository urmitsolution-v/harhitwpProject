/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'de', {
	label: 'Stil',
	panelTitle: 'Formatierungsstile',
	panelTitle1: 'Blockstile',
	panelTitle2: 'Inline Stilart',
	panelTitle3: 'Objektstile'
} );
