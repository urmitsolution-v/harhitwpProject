/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'oc', {
	label: 'Estils',
	panelTitle: 'Estils de mesa en pagina',
	panelTitle1: 'Estils de blòt',
	panelTitle2: 'Estils en linha',
	panelTitle3: 'Estils d\'objècte'
} );
